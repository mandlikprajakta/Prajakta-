#ifndef INVENTORY_H
#define INVENTORY_H

#ifdef __cplusplus
extern "C" {
#endif

/* ---------------------------------------------------------------
 * Data layout (matches the binary record on disk exactly)
 * --------------------------------------------------------------- */
typedef struct {
    int   id;
    char  name[40];
    int   quantity;
    float price;
    int   is_deleted;   /* 0 = active, 1 = soft-deleted */
} Item;

/* ---------------------------------------------------------------
 * C backend – all functions return 1 on success, 0 on failure.
 * list_items returns the number of active items copied.
 * --------------------------------------------------------------- */
int add_item   (const Item  item);
int get_item   (int id, Item *out);
int update_item(int id, const Item *updated);
int delete_item(int id);
int list_items (Item *buffer, int max_items);

#ifdef __cplusplus
}
#endif

#endif /* INVENTORY_H */
