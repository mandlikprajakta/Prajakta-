#ifndef INVENTORY_MANAGER_H
#define INVENTORY_MANAGER_H

/*
 * InventoryManager.h
 *
 * C++ class that provides the interactive console menu and delegates
 * all storage operations to the C backend (inventory.c).
 */

class InventoryManager {
public:
    /* Enter the main loop – returns only when the user exits.     */
    void run();

private:
    void print_menu() const;
    void do_add();
    void do_view();
    void do_update();
    void do_delete();
    void do_list();
};

#endif /* INVENTORY_MANAGER_H */
